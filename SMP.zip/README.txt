Course Name: CS378
Unique: 91060

First Name: Ryan 
Last Name: Kluck
EID: rrk357
E-mail: rk122988@utexas.edu
Estimated number of hours:6
Actual number of hours: 9
